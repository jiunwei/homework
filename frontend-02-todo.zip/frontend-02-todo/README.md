# Front-End Engineer Exercise: Todo

## Purpose

To fulfill the requirements stated at [https://gist.github.com/aravindet/ce19c019b774794c4e23df5760e8cca5](https://gist.github.com/aravindet/ce19c019b774794c4e23df5760e8cca5).

## Installation

```
npm install
```

## Usage

To run the app:

```
npm start
```

To run the tests:

```
npm test
```
