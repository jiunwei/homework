export default {
  TASK: 'task'
};
