import sys

if __name__ == '__main__':
    from .game import main
    main(sys.argv[1:])
