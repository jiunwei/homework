# Zopim Take Home Exercise: Tic-Tac-Toe

## Purpose

To fulfill the requirements given via PDF.

## Usage

While the game can be played using either Python 2 or 3, tests must be run using Python 3.

To run the app:

```
python main.py
```

To change the dimension of the grid used, supply N as a command line argument:

```
python main.py 5
```

To run the tests:

```
python3 -m unittest tests.test_game
```
