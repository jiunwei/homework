#!/usr/bin/env python

import sys

if __name__ == '__main__':
    from tictactoe.game import main
    main(sys.argv[1:])
